function setup() {
  createCanvas(2000,800);
}
function draw() {
  background(220);
  text ("Hello all my name is Abhijit Sahu",20,20);
  text ("Today I will tell you how to make Maggi",20,50);
  text ("Step - 1 : Take some maggi strings given inthe packet",20,100);
  text ("Step - 2 : Put some vegetables in it",20,120);
  text ("Step - 3 : Take some water in the pan",20,140);
  text ("Step - 4 : Keep the maggi strings in it",20,160);
  
}